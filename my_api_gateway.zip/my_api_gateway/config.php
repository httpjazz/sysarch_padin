<?php
$valid_api_keys = [
    'key123' => 'UserA',
    'key456' => 'UserB'
];

$rate_limit = 10; // max requests
$rate_window = 60; // in seconds
?>
const axios = require('axios');
const Order = require('../models/orderModel');

exports.placeOrder = async (req, res) => {
  const { userId, productId, quantity } = req.body;

  try {
    // Fetch user info from user-nexus
    const userRes = await axios.get(`http://localhost:5000/api/users/${userId}`);
    // Fetch product info from product-hub
    const productRes = await axios.get(`http://localhost:5001/api/products`);

    const productInfo = productRes.data.find(p => p._id === productId);
    if (!productInfo) return res.status(404).json({ error: 'Product not found' });

    // Save order
    const newOrder = new Order({
      userId,
      productId,
      quantity,
      userInfo: userRes.data,
      productInfo
    });

    await newOrder.save();
    res.status(201).json({ message: 'Order placed', order: newOrder });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Order failed', details: error.message });
  }
};

exports.getOrders = async (req, res) => {
  const orders = await Order.find();
  res.json(orders);
};

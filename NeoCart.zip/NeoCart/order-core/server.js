const express = require('express');
const connectDB = require('./config/db');
const orderRoutes = require('./routes/orderRoutes');

const app = express();
connectDB();
app.use(express.json());
app.use('/api/orders', orderRoutes);

const PORT = 5002;
app.listen(PORT, () => {
  console.log(`🧾 Order Core is live on port ${PORT}`);
});

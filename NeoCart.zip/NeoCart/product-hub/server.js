const express = require('express');
const connectDB = require('./config/db');
const productRoutes = require('./routes/productRoutes');

const app = express();
connectDB();
app.use(express.json());
app.use('/api/products', productRoutes);

const PORT = 5001;
app.listen(PORT, () => {
  console.log(`🛍️ Product Hub is running on port ${PORT}`);
});

const Product = require('../models/productModel');

exports.addProduct = async (req, res) => {
  const { name, description, price, stock } = req.body;
  const product = new Product({ name, description, price, stock });
  await product.save();
  res.status(201).json({ message: 'Product added', product });
};

exports.getProducts = async (req, res) => {
  const products = await Product.find();
  res.json(products);
};
